import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(RutApp());

_launchURLBrowser() async {
  var url = Uri.parse("https://www.youtube.com/watch?v=GF--t6f3xdk&t=2s");
  if (await canLaunchUrl(url)) {
    await launchUrl(url);
  } else {
    throw 'Could not launch $url';
  }
}
class NewScreen extends StatefulWidget{
  const NewScreen({Key? key}) : super(key: key);

  @override
  State<NewScreen> createState() => _NewScreenState();
}
class _NewScreenState extends State<NewScreen> {

  @override
  // TODO: implement widget
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.blue,
          brightness: Brightness.dark,
        ),
        title: 'liceo classico',
        home: Scaffold(
          appBar: AppBar(
              backgroundColor: const Color(0xff40c4ff),
              title: const Text('liceo classico')),
          body: Builder(builder: (context) {
            return SingleChildScrollView(
                child: Column(children: [
                  Container(height: 50,
                  ),
                  Image.network('https://scaling.spaggiari.eu/MIIT0037/thumbnail/4989.png&rs=%2FtccTw2MgxYfdxRYmYOB6Pk9jQH5POS%2FquVc8aOi3ns2htM1BhF%2Fr5nAtRVDWvfTyMAZSK1CdbWaDHnglQjglAuFwI5cB%2FVmg%2FuX4At01ifvHVhzR520%2FYme%2BqShUDP%2B9Qj7hNmcQs3PUZ%2B9YD5vdA%3D%3D'),
                  Container(height: 50,
                  ),
                  const Text('Il percorso del liceo classico è indirizzato allo studio della civiltà classica e della cultura umanistica. Favorisce una formazione letteraria, storica e filosofica idonea a comprenderne il ruolo nello sviluppo della civiltà e della tradizione occidentali e nel mondo contemporaneo sotto un profilo simbolico, antropologico e di confronto di valori. Favorisce l’acquisizione dei metodi propri degli studi classici e umanistici, all’interno di un quadro culturale che, riservando attenzione anche alle scienze matematiche, fisiche e naturali, consente di cogliere le intersezioni fra i saperi e di elaborare una visione critica della realtà. Guida lo studente ad approfondire e a sviluppare le conoscenze e le abilità e a maturare le competenze a ciò necessarie'),
                  Container(height: 50,),
                  Center(
                    child: InkWell(
                        child: const Text('clicca qui per il video di presentazione dell indirizzo',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.black, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('https://www.youtube.com/watch?v=egD709oqZfM')
                    ),
                  ),
                  Container(height: 50,),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const RutApp()));
                    } ,child: const Text('torna alla pagina iniziale'),
                  ),
                ],)
            );
          }
            ,),));
  }
}
class NewScreen1 extends StatefulWidget{
  const NewScreen1({Key? key}) : super(key: key);

  @override
  State<NewScreen1> createState() => _NewScreenState1();
}
class _NewScreenState1 extends State<NewScreen1> {

  @override
  // TODO: implement widget
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.green,
          brightness: Brightness.dark,
        ),
        title: 'liceo linguistico',
        home: Scaffold(
          appBar: AppBar(
              backgroundColor: const Color(0xff00e676),
              title: const Text('liceo linguistico')),
          body: Builder(builder: (context) {
            return SingleChildScrollView(
                child: Column(children: [
                  Container(height: 50,
                  ),
                  Image.network('https://scaling.spaggiari.eu/MIIT0037/thumbnail/4991.png&rs=%2FtccTw2MgxYfdxRYmYOB6Pk9jQH5POS%2FquVc8aOi3ns2htM1BhF%2Fr5nAtRVDWvfTyMAZSK1CdbWaDHnglQjglAuFwI5cB%2FVmg%2FuX4At01ifvHVhzR520%2FYme%2BqShUDP%2B9Qj7hNmcQs3PUZ%2B9YD5vdA%3D%3D'),
                  Container(height: 50,
                  ),
                  const Text('Il percorso del Liceo Linguistico fornisce allo studente gli strumenti culturali e metodologici per una comprensione approfondita e critica della realtà, all interno di un’ampia dimensione formativa, garantita, oltre che dalle discipline di area linguistica, anche dal contributo delle discipline afferenti all’asse storico sociale e all’asse scientifico. In particolare la sua specificità consiste nel guidare lo studente ad approfondire le conoscenze, le abilità e le competenze necessarie per acquisire la padronanza comunicativa di tre lingue straniere e per comprendere criticamente l identità storica e culturale di tradizioni e civiltà diverse, riconoscerne i molteplici rapporti e stabilire raffronti tra la lingua italiana e altre lingue moderne, anche tramite esperienze di studio nei paesi in cui si parlano le lingue studiate.'),
                  Container(height: 50,),
                  Center(
                    child: InkWell(
                        child: const Text('clicca qui per la presentazione dell indirizzo',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.black, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('https://cspace.spaggiari.eu/pub/MIIT0037/LL-VARIE/Presentazione%20LING_2021%2022.pdf')
                    ),
                  ),
                  Container(height: 50,),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const RutApp()));
                    } ,child: const Text('torna alla pagina iniziale'),
                  ),
                ],)
            );
          }
            ,),));
  }
}
class NewScreen2 extends StatefulWidget{
  const NewScreen2({Key? key}) : super(key: key);

  @override
  State<NewScreen2> createState() => _NewScreenState2();
}
class _NewScreenState2 extends State<NewScreen2> {

  @override
  // TODO: implement widget
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.yellow,
          brightness: Brightness.dark,
        ),
        title: 'liceo scienze umane',
        home: Scaffold(
          appBar: AppBar(
              backgroundColor: const Color(0xffffff00),
              title: const Text('liceo scienze umane')),
          body: Builder(builder: (context) {
            return SingleChildScrollView(
                child: Column(children: [
                  Container(height: 50,
                  ),
                  Image.network('https://scaling.spaggiari.eu/MIIT0037/thumbnail/4993.png&rs=%2FtccTw2MgxYfdxRYmYOB6Pk9jQH5POS%2FquVc8aOi3ns2htM1BhF%2Fr5nAtRVDWvfTyMAZSK1CdbWaDHnglQjglAuFwI5cB%2FVmg%2FuX4At01ifvHVhzR520%2FYme%2BqShUDP%2B9Qj7hNmcQs3PUZ%2B9YD5vdA%3D%3D'),
                  Container(height: 50,
                  ),
                  const Text('Il percorso del liceo delle scienze umane è indirizzato allo studio delle teorie esplicative dei fenomeni collegati alla costruzione dell’identità personale e delle relazioni umane e sociali. Guida lo studente ad approfondire e a sviluppare le conoscenze e le abilità e a maturare le competenze necessarie per cogliere la complessità e la specificità dei processi formativi. Assicura la padronanza dei linguaggi, delle metodologie e delle tecniche di indagine nel campo delle scienze umane'),
                  Container(height: 50,),
                  Center(
                    child: InkWell(
                        child: const Text('clicca qui per il video di presentazione dell indirizzo',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.black, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('https://youtu.be/7PL3GnRa4HQ')
                    ),
                  ),
                  Container(height: 50,),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const RutApp()));
                    } ,child: const Text('torna alla pagina iniziale'),
                  ),
                ],)
            );
          }
            ,),));
  }
}
class NewScreen3 extends StatefulWidget{
  const NewScreen3({Key? key}) : super(key: key);

  @override
  State<NewScreen3> createState() => _NewScreenState3();
}
class _NewScreenState3 extends State<NewScreen3> {

  @override
  // TODO: implement widget
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.orange,
          brightness: Brightness.dark,
        ),
        title: 'istituto tecnico informatico',
        home: Scaffold(
          appBar: AppBar(
              title: const Text('istituto tecnico informatico'),
              backgroundColor: const Color(0xffff9800)),
          body: Builder(builder: (context) {
            return SingleChildScrollView(
                child: Column(children: [
                  Container(height: 50,
                  ),
                  Image.network('https://scaling.spaggiari.eu/MIIT0037/thumbnail/4999.png&rs=%2FtccTw2MgxYfdxRYmYOB6Pk9jQH5POS%2FquVc8aOi3ns2htM1BhF%2Fr5nAtRVDWvfTyMAZSK1CdbWaDHnglQjglAuFwI5cB%2FVmg%2FuX4At01ifvHVhzR520%2FYme%2BqShUDP%2B9Qj7hNmcQs3PUZ%2B9YD5vdA%3D%3D'),
                  Container(height: 50,
                  ),
                  const Text('Caratterizzato dalle discipline di Informatica, Telecomunicazioni, Tecnologia e progettazione di sistemi informatici e di telecomunicazioni, Sistemi e Reti il corso prepara principalmente alla professione di perito informatico o agli studi universitari nel campo tecnico-scientifico (Politecnico).'),
                  Container(height: 50,),
                  Center(
                    child: InkWell(
                        child: const Text('clicca qui per il video di presentazione dell indirizzo',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.black, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('https://youtu.be/ZemRK_UNKg4')
                    ),
                  ),
                  Container(height: 50,),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const RutApp()));
                    } ,child: const Text('torna alla pagina iniziale'),
                  ),
                ],)
            );
          }
            ,),));
  }
}
class NewScreen4 extends StatefulWidget{
  const NewScreen4({Key? key}) : super(key: key);

  @override
  State<NewScreen4> createState() => _NewScreenState4();
}
class _NewScreenState4 extends State<NewScreen4> {

  @override
  // TODO: implement widget
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.purple,
          brightness: Brightness.dark,
        ),
        title: 'istituto tecnico amministrazione finanza e marketing',
        home: Scaffold(
          appBar: AppBar(
              backgroundColor: const Color(0xffe040fb),
              title: const Text('istituto tecnico amministrazione finanza e marketing')),
          body: Builder(builder: (context) {
            return SingleChildScrollView(
                child: Column(children: [
                  Container(height: 50,
                  ),
                  Image.network('https://scaling.spaggiari.eu/MIIT0037/thumbnail/5001.png&rs=%2FtccTw2MgxYfdxRYmYOB6Pk9jQH5POS%2FquVc8aOi3ns2htM1BhF%2Fr5nAtRVDWvfTyMAZSK1CdbWaDHnglQjglAuFwI5cB%2FVmg%2FuX4At01ifvHVhzR520%2FYme%2BqShUDP%2B9Qj7hNmcQs3PUZ%2B9YD5vdA%3D%3D'),
                  Container(height: 50,
                  ),
                  const Text('Il Diplomato in “Amministrazione, Finanza e Marketing” ha competenze generali nel campo dei macrofenomeni economici nazionali ed internazionali, della normativa civilistica e fiscale, dei sistemi e processi aziendali (organizzazione, pianificazione, programmazione, amministrazione, finanza e controllo), degli strumenti di marketing, dei prodotti assicurativo-finanziari e dell’economia sociale. Integra le competenze dell’ambito professionale specifico con quelle linguistiche e informatiche per operare nel sistema informativo dell’azienda e contribuire sia all’innovazione sia al miglioramento organizzativo e tecnologico dell’impresa inserita nel contesto internazionale.'),
                  Container(height: 50,),
                  Center(
                    child: InkWell(
                        child: const Text('clicca qui per il video di presentazione dell indirizzo',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.black, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('https://youtu.be/OJqGElL8W8E')
                    ),
                  ),
                  Container(height: 50,),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const RutApp()));
                    } ,child: const Text('torna alla pagina iniziale'),
                  ),
                ],)
            );
          }
            ,),));
  }
}
class NewScreen5 extends StatefulWidget{
  const NewScreen5({Key? key}) : super(key: key);

  @override
  State<NewScreen5> createState() => _NewScreenState5();
}
class _NewScreenState5 extends State<NewScreen5> {

  @override
  // TODO: implement widget
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.pink,
          brightness: Brightness.dark,
        ),
        title: 'Indirizzo Chimica, Materiali e Biotecnologie',
        home: Scaffold(
          appBar: AppBar(
              backgroundColor: const Color(0xfff50057),
              title: const Text('Indirizzo Chimica, Materiali e Biotecnologie')),
          body: Builder(builder: (context) {
            return SingleChildScrollView(
                child: Column(children: [
                  Container(height: 50,
                  ),
                  Image.network('https://scaling.spaggiari.eu/MIIT0037/thumbnail/4997.png&rs=%2FtccTw2MgxYfdxRYmYOB6Pk9jQH5POS%2FquVc8aOi3ns2htM1BhF%2Fr5nAtRVDWvfTyMAZSK1CdbWaDHnglQjglAuFwI5cB%2FVmg%2FuX4At01ifvHVhzR520%2FYme%2BqShUDP%2B9Qj7hNmcQs3PUZ%2B9YD5vdA%3D%3D'),
                  Container(height: 50,
                  ),
                  const Text('ha competenze specifiche nel campo dei materiali, delle analisi strumentali chimico-biologiche, nei processi di produzione, in relazione alle esigenze delle realtà territoriali, negli ambiti chimico, merceologico, biologico, farmaceutico, tintorio e conciario'),
                  Container(height: 50,),
                  Center(
                    child: InkWell(
                        child: const Text('clicca qui per il video di presentazione dell indirizzo',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                fontStyle: FontStyle.italic,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.black, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('https://youtu.be/57bIGrJF2gY')
                    ),
                  ),
                  Container(height: 50,),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const RutApp()));
                    } ,child: const Text('torna alla pagina iniziale'),
                  ),
                ],)
            );
          }
            ,),));
  }
}
class NewScreen6 extends StatefulWidget{
  const NewScreen6({Key? key}) : super(key: key);

  @override
  State<NewScreen6> createState() => _NewScreenState6();
}
class _NewScreenState6 extends State<NewScreen6> {

  @override
  // TODO: implement widget
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.red,
          brightness: Brightness.dark,
        ),
        title: 'Indirizzo Elettronica ed Elettrotecnica',
        home: Scaffold(
          appBar: AppBar(
              backgroundColor: const Color(0xfff44336),
              title: const Text('Indirizzo Elettronica ed Elettrotecnica')),
          body: Builder(builder: (context) {
            return SingleChildScrollView(
                child: Column(children: [
                  Container(height: 50,
                  ),
                  Image.network('https://scaling.spaggiari.eu/MIIT0037/thumbnail/4995.png&rs=%2FtccTw2MgxYfdxRYmYOB6Pk9jQH5POS%2FquVc8aOi3ns2htM1BhF%2Fr5nAtRVDWvfTyMAZSK1CdbWaDHnglQjglAuFwI5cB%2FVmg%2FuX4At01ifvHVhzR520%2FYme%2BqShUDP%2B9Qj7hNmcQs3PUZ%2B9YD5vdA%3D%3D'),
                  Container(height: 50,
                  ),
                  const Text('ha competenze specifiche nel campo dei materiali e delle tecnologie costruttive dei sistemi elettrici, elettronici e delle macchine elettriche, della generazione, elaborazione e trasmissione dei segnali elettrici ed elettronici, dei sistemi per la generazione, conversione e trasporto dell’energia elettrica e dei relativi impianti di distribuzione'),
                  Container(height: 50,),
                  Center(
                    child: InkWell(
                        child: const Text('clicca qui per il video di presentazione dell indirizzo',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.black, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('https://youtu.be/j2MXbEDeU9U')
                    ),
                  ),
                  Container(height: 50,),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => const RutApp()));
                    } ,child: const Text('torna alla pagina iniziale'),
                  ),
                ],)
            );
          }
            ,),));
  }
}
class RutApp extends StatelessWidget {
  const RutApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(
          primarySwatch: Colors.cyan,
          brightness: Brightness.dark,
        ),
        title: 'ITSOS MARIE CURIE',

        home: Scaffold(
            appBar: AppBar(
                title: const Text('ITSOS MARIE CURIE')),
            body: Builder(builder: (context){
              flutter_icons:
              android: "launcher_icon";
              ios: false;
              image_path: "assets/icon/icon.png";
              adaptive_icon_background: "assets/icon/icon-background.png";
              adaptive_icon_foreground: "assets/icon/icon.png";
              return SingleChildScrollView(
                child: Column(children: [
                  Title(color: Colors.black, child: const Text('LICEO ED ISTITUTO TECNICO - SETTE INDIRIZZI DI STUDIO',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 35, fontStyle: FontStyle.italic,))),
                  Container(height: 50,
                  ),
                  const Text('L’ITSOS “Marie Curie” di Cernusco sul Naviglio trae le sue origini da una sperimentazione di ordinamento del 1971, ed è stato istituito come Istituto Tecnico Statale a Ordinamento Speciale con DPR 22/5/1978. Dalle tre classi prime del 1971/72, per un totale di 61 allievi, l’ITSOS è progressivamente cresciuto. Ogni anno l’Istituto ospita circa 1.700 studenti, 180 docenti e 40 unità di personale ATA.'),
                  Container(height: 25,),
                  Image.network('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRS4bMnG8GLYcvl9xmky-ChtGEUikU8J6eVew&usqp=CAU'),
                  const Text('|'),
                  const Text('|'),
                  const Text('V'),
                  ElevatedButton(
                    onPressed: _launchURLBrowser,
                    style:
                    ButtonStyle(
                      padding:
                      MaterialStateProperty.all(const EdgeInsets.all(5.0)),
                      textStyle: MaterialStateProperty.all(
                        const TextStyle(color: Colors.black),
                      ),
                    ), child: const Text('VIDEO PRESENTAZIONE INDIRIZZI'),
                  ),
                  Container(height: 50,),
                  const Text('DOVE SIAMO?',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      )),
                  Container(height: 25,),
                  Image.network('https://italiarecensioni.com/map/426236.png'),
                  Container(height: 25,),
                  const Text('la scuola mette a disposizione oltre a 75 aule, un auditorium, un’ampia aula multifunzione, numerosi e ben attrezzati spazi di lavoro, numerosi laboratori tecnici (informatica, chimica, elettronica), un laboratorio linguistico, un laboratorio per le discipline umanistiche, un aula 3.0, palestre e campi sportivi, una biblioteca, una sala stampa, ampi spazi esterni con parcheggio auto e tettoie con rastrelliere per le bicilette. Sono inoltre presenti la mensa e il servizio bar, oltre a punti ristoro dotati di distributori automatici.'),
                  Container(height: 70,),
                  Center(
                    child: InkWell(
                        child: const Text('per la visita virtuale della scuola clicca su questo link',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.black, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('https://www.google.com/maps/@45.5229851,9.3127137,3a,82.2y,88.49h,88.43t/data=!3m7!1e1!3m5!1sAF1QipOZGEOOCOQgvB7-F4WK2UiIOWvygle4NmhxqK_b!2e10!3e12!7i7200!8i3600')
                    ),
                  ),
                  Container(height: 50,),
                  const Text('QUALI INDIRIZZI OFFRIAMO?',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      )),
                  Container(height: 50,),
                  const Text('L ITSOS Marie Curie offre ben sette indirizzi di studio.'),
                  Container(height: 50,),
                  SizedBox(
                    width: 250.0,
                    height: 60.0,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const NewScreen()));
                      } ,child: const Text('liceo classico'),
                    ),
                  ),
                  Container(height: 50,),
                  SizedBox(
                    width: 250.0,
                    height: 60.0,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.green),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const NewScreen1()));
                      } ,
                      child: const Text('liceo linguistico'),
                    ),
                  ),
                  Container(height: 50,),
                  SizedBox(
                    width: 250.0,
                    height: 60.0,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.amberAccent),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const NewScreen2()));
                      } ,child: const Text('liceo scienze umane'),
                    ),
                  ),
                  Container(height: 50,),
                  SizedBox(
                    width: 250.0,
                    height: 60.0,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.deepOrange),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const NewScreen3()));
                      } ,child: const Text('isituto tecnico informatico'),
                    ),
                  ),
                  Container(height: 50,),
                  SizedBox(
                    width: 250.0,
                    height: 60.0,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.purple),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const NewScreen4()));
                      } ,child: const Text('isituto tecnico amministrazione finanza e marketing'),
                    ),
                  ),
                  Container(height: 50,),
                  SizedBox(
                    width: 250.0,
                    height: 60.0,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.pink),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const NewScreen5()));
                      } ,child: const Text('Indirizzo Chimica, Materiali e Biotecnologie'),
                    ),
                  ),
                  Container(height: 50,),
                  SizedBox(
                    width: 250.0,
                    height: 60.0,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.red),
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (context) => const NewScreen6()));
                      } ,child: const Text('Indirizzo Elettronica ed Elettrotecnica'),
                    ),
                  ),
                  Container(height: 50,),
                  Center(
                    child: InkWell(
                        child: const Text('per informazioni invece suL sito ufficiale della scuola clicca su questo link',
                            style: TextStyle(
                                color: Colors.indigo,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.white, offset: Offset(1, 4), blurRadius: 1),
                                  Shadow(color: Colors.blueAccent, offset: Offset(2, 1), blurRadius: 2)
                                ]
                            )),
                        onTap: () => launch('www.itsos-mariecurie.edu.it')
                    ),
                  ),
                  Container(height: 50,),
                  const Text('Tel: Tel. 02.9240552'),
                  const Text('Email: info@itsos-mariecurie.it'),
                  const Text('instagram: itsos_mariecurie'),
                ]),
              );
            }
            )
        )
    );
  }

  void ModelToysScaffold(Set set) {}
}


